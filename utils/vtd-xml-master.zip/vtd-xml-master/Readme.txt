README (2/2011)

  This is VTD-XML Version 2.10 light in Java based on Virtual Token Descriptor (VTD).

  
Files Included in this directory
  README: this file.
  
  Full GPL license is in "License.txt."

  The installation guide is in "install.txt."

  "com\ximpleware\" and "com\ximpleware\parser\" 
contain the source code.
  
  "vtd-xml-light.zip" contains the .class files needed to use this API.  

  Some examples are under "/examples."

  Also you can read all the documents online at "http://vtd-xml.sf.net."

  Let us know what you think and help us improve the software. Please email us: 
info@ximpleware.com. 
